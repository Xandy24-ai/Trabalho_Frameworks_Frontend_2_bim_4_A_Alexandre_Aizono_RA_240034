
export const Produtos = () => {
    return(
        <>
            <h1>Pg Produtos</h1>
        </>
    )
}